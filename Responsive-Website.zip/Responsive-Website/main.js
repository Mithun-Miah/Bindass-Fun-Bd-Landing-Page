/*$(document).ready(function(){

    // This Sytex For JQuery and All code write Here

});*/

